package CientApp.clientCommands;

import GUIPackage.MainWindow;

public class SelectPlayer extends BaseClientCommand {
    @Override
    public void execute(String[] args, MainWindow mainWindow) {

    }
}
