package CientApp.clientCommands;

import GUIPackage.MainWindow;

public class InitGUI extends BaseClientCommand {

    public static final String NAME = "InitGUI";

    @Override
    public void execute(String[] args, MainWindow mainWindow) {

    }
}
