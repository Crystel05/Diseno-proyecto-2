package CientApp.clientCommands;

import GUIPackage.MainWindow;

public class SetWin extends BaseClientCommand {

    public static final String NAME = "SetWin";

    @Override
    public void execute(String[] args, MainWindow mainWindow) {

    }
}
