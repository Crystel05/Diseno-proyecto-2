package CientApp.clientCommands;

import GUIPackage.MainWindow;

public class SuggestGiveUp extends BaseClientCommand {

    @Override
    public void execute(String[] args, MainWindow mainWindow) {

    }
}
