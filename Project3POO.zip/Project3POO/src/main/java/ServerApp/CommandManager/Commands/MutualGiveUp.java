package ServerApp.CommandManager.Commands;

public class MutualGiveUp implements ICommand {

    @Override
    public void execute(String[] args) {

    }

}
