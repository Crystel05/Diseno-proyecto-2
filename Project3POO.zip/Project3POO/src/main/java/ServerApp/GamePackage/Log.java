/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServerApp.GamePackage;

/**
 *
 * @author Fernando Alvarez
 */
public class Log {
    
    private String log;
        
    public void addToLog(String msg){//Una lista en pantalla con los turnos
        //Fecha hora comando parametros y resultado
    }
    
    public void getLog(){
        
    }
    
}
