package ServerApp.GamePackage;

import java.io.Serializable;

public enum Types implements Serializable{
    FIRE,
    AIR,
    WATER,
    WHITE_MAGIC,
    BLACK_MAGIC,
    ELECTRICITY,
    ICE,
    ACID,
    SPIRIT,
    IRON
}
